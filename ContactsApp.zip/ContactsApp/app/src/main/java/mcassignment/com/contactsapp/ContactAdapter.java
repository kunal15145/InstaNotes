package mcassignment.com.contactsapp;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.viewholder> {

    private ArrayList<Contact> contacts;
    private Context context;

    public ContactAdapter(Context context, ArrayList<Contact> contacts) {
        this.context = context;
        this.contacts = contacts;
    }

    public class viewholder extends RecyclerView.ViewHolder {

        public TextView contact_name;
        public CardView cardView;
        public ImageView imageViewcall;
        public ImageView imageViewmail;

        public viewholder(View itemView) {
            super(itemView);
            contact_name = itemView.findViewById(R.id.textView);
            cardView = itemView.findViewById(R.id.card_view);
            imageViewcall = itemView.findViewById(R.id.call_button);
            imageViewmail = itemView.findViewById(R.id.mail_button);
        }

    }

    @Override
    public viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_brief_info, parent, false);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(final viewholder holder, int position) {

        final Contact contact = contacts.get(position);
        holder.contact_name.setText(contact.getName());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("pic",contact.getPicuri());
                bundle.putString("email",contact.getEmail());
                bundle.putString("phone",contact.getPhone());
                bundle.putString("name",contact.getName());
                FragmentTransaction fragmentTransaction = ((AppCompatActivity) context).getFragmentManager().beginTransaction();
                ContactDetailFragment fragment = new ContactDetailFragment();
                fragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.container, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return contacts.size();
    }

}
