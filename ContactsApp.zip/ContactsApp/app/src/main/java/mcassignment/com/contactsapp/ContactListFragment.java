package mcassignment.com.contactsapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class ContactListFragment extends android.app.Fragment{

    private RecyclerView recyclerView;
    private ContactAdapter contactAdapter;
    private final ArrayList<Contact> contacts = new ArrayList<>();
    private final int Permission_toREAD = 1;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_contact_list, container, false);
        recyclerView = v.findViewById(R.id.contacts_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(v.getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        contacts.clear();
        Log.d("abc","msg"+contacts.size());
        contacts.add(new Contact("Harshit Verma","9971795216",R.drawable.user,"harshit15037@iiitd.ac.in","1"));
        contactAdapter = new ContactAdapter(v.getContext(), contacts);
        recyclerView.setAdapter(contactAdapter);
        return v;
    }
}
