package mcassignment.com.contactsapp;

import android.app.Fragment;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class ContactDetailFragment extends Fragment {

    private String name;
    private String phone;
    private String email;
    private int uri;
    ImageView imageView;
    TextView mname,nemail,mphone;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        imageView = view.findViewById(R.id.image);
        mname = view.findViewById(R.id.name);
        nemail = view.findViewById(R.id.email);
        mphone = view.findViewById(R.id.phone);

       imageView.setImageDrawable(getResources().getDrawable(R.drawable.user));
        mname.setText(name);
        mphone.setText(phone);
        nemail.setText(email);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        name = getArguments().getString("name");
        phone = getArguments().getString("phone");
        email = getArguments().getString("email");
        uri = getArguments().getInt("pic");
        return inflater.inflate(R.layout.contact_detail,container,false);
    }
}
