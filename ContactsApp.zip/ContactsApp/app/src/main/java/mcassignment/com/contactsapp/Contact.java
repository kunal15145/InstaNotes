package mcassignment.com.contactsapp;

public class Contact {

    private String name;
    private int picuri;
    private String email;
    private String phone;
    private String id;

    Contact(String name,String phone,int picuri,String email,String id){
        this.name = name;
        this.picuri = picuri;
        this.phone = phone;
        this.email = email;
        this.id = id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPicuri() {
        return picuri;
    }

    public void setPicuri(int picuri) {
        this.picuri = picuri;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
